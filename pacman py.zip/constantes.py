   #Dimensões da tela
LARGURA = 480
ALTURA = 600

#titulo do jogo
TITULO_JOGO = 'PACMAN'

#fps
FPS = 30

#Cores
PRETO = (0 ,0 ,0)
AMARELO = (244,233, 51)
BRANCO = (255,255,255)

#imagens
SPRITESHEET = 'spritsheet.png'
PACMAN_START_LOGO = 'pacman-logo-1.png'

#Fonte
FONTE = 'arial'